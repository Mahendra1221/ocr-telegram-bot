# OCR Telegram Bot

This bot extracts Name, Number, and Class from any screenshot using OCR and returns the result in this format:

```
Name - 
Number - 
Class - 
Amount - 
Transaction ID / UTR -
```

Just send an image, and get the result!